# NCS Roster Watch

Watches NCS fastpitch team roster pages on **playNCS.com** and alerts you when a
player is **removed** (or added) from any team you track.

Runs on a schedule via **GitHub Actions** — nothing of yours has to be running.
playNCS team pages are plain public HTML (no API, token, or login), so the
script just fetches each team page, reads the roster table, and compares it to
the last snapshot.

```
team pages --> parse roster table --> diff vs snapshots/latest.json
                                           |
                      +--------------------+--------------------+
                      v                     v                    v
               reports/changes-*.md   notify (issue/email/slack)  commit snapshot
```

Each player on a team page links to a **stable player id**
(`/Fastpitch/Players/Details/<id>/...`). The diff keys on that id, so a jersey
change or name-spelling edit never shows up as a false remove/add -- only an
actual roster move does.

State lives in `snapshots/latest.json`, committed every run, so
`git log -p snapshots/latest.json` is itself a full history of who joined/left
and when. `reports/changelog.csv` accumulates every change with a timestamp.

---

## These rosters contain minors' names -- keep the repo PRIVATE

The snapshots and reports will contain kids' names, jersey numbers, and player
ids. That data is already public on playNCS, but committing it into a **public**
GitHub repo re-publishes and aggregates it. Make this repository **private**
(Settings -> General -> Danger Zone -> Change visibility) before the first run.
GitHub Actions, scheduled jobs, issues, and committing snapshots all work fine
in a private repo.

---

## Setup

1. **Make the repo private** (see above), then push these files to it.

2. **Add the teams you want to watch** in `config.yaml`. Easiest path: open each
   team on playncs.com and copy the address-bar URL into the `teams:` list:
   ```yaml
   teams:
     - url: "https://www.playncs.com/Fastpitch/Teams/Details/39016/bananas-2k15"
     - url: "https://www.playncs.com/Fastpitch/Teams/Details/41465/hotshots-2k15-villegas"
   ```

3. **Pick how you're notified** (`notify:` in `config.yaml`):
   - `github_issue` -- on by default, zero setup. Opens an issue per change.
   - `email` -- uncomment and add `SMTP_*` repo secrets (Gmail needs an *app password*).
   - `slack` -- uncomment and add a `SLACK_WEBHOOK_URL` secret.

4. **Adjust the schedule** in `.github/workflows/roster-watch.yml`
   (`cron: "0 13 * * *"` = daily ~8 AM Central), or run it any time from the
   **Actions tab -> NCS Roster Watch -> Run workflow**.

The first scheduled run just records the baseline silently. From the second run
on, any roster change is reported and logged.

---

## Test locally first

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# Offline: parse the bundled sample pages (no network needed)
TID="https://www.playncs.com/Fastpitch/Teams/Details/39016/bananas-2k15"
python ncs_monitor.py --input samples/bananas_before.html --team-id "$TID"   # baseline
python ncs_monitor.py --input samples/bananas_after.html  --team-id "$TID"   # detects a remove + an add
```

Then try it live against the real teams in your config:
```bash
python ncs_monitor.py            # first run = baseline
python ncs_monitor.py --dry-run  # later: see changes without saving/notifying
```

---

## Finding more teams to watch

This tracks a watchlist of specific team pages. To discover central-TX 12U teams
to add, use playNCS **Find a Team** (`playncs.com/Fastpitch/Teams`) or an event's
**Who's Coming** list, then copy each team's URL into `config.yaml`. (Bulk
discovery by city is a separate problem -- that listing is loaded dynamically and
isn't covered here.)

## Notes & limits

- A player counts as "removed" only relative to a team you're tracking. If a
  whole team's page stops listing anyone, every prior player reads as removed --
  worth a glance before trusting a mass-removal alert.
- Be a good citizen: the default is one request per team with a 2-second gap,
  once a day. Don't crank the schedule up.
- Dependencies: `pyyaml` and `beautifulsoup4` (uses the stdlib `html.parser`,
  no lxml needed -- installs cleanly on new Python versions).
